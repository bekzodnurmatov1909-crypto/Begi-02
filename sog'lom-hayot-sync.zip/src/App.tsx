import Dashboard from './components/Dashboard';
import { Toaster } from '@/components/ui/sonner';

export default function App() {
  return (
    <main className="min-h-screen bg-slate-50">
      <Dashboard />
      <Toaster position="top-center" />
    </main>
  );
}
