import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  Droplets, 
  Moon, 
  Flame, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle,
  Smartphone,
  ArrowRightLeft
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { fetchHealthConnectData, syncHealthData, checkConnection, type HealthData } from '@/src/lib/healthConnect';

export default function Dashboard() {
  const [data, setData] = useState<HealthData | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Initial data fetch
    loadData();
  }, []);

  const loadData = async () => {
    const healthData = await fetchHealthConnectData();
    setData(healthData);
  };

  const handleSync = async () => {
    if (!data) return;
    
    // Check connection first
    const isActuallyConnected = await checkConnection();
    if (!isConnected || !isActuallyConnected) {
      toast.error("Health Connect ulanmagan! Iltimos, avval ulanishni o'rnating.", {
        icon: <AlertCircle className="w-5 h-5 text-red-500" />,
      });
      return;
    }
    
    setIsSyncing(true);
    toast.info("Health Connect ma'lumotlari olinmoqda...");
    
    // 1. Fetch from Health Connect
    const freshData = await fetchHealthConnectData();
    setData(freshData);
    
    // 2. Sync to external site
    const success = await syncHealthData(freshData);
    
    setIsSyncing(false);
    
    if (success) {
      toast.success("Ma'lumotlar soglomhayot.vercel.app saytiga muvaffaqiyatli yuborildi!");
    } else {
      toast.error("Sinxronizatsiya xatosi yuz berdi.");
    }
  };

  const toggleConnection = () => {
    setIsConnected(!isConnected);
    if (!isConnected) {
      toast.success("Health Connect-ga ulanish o'rnatildi");
    } else {
      toast.info("Health Connect-dan uzildi");
    }
  };

  if (!data) return null;

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans">
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">Sog'lom Hayot</h1>
            <p className="text-sm text-slate-500">Health Connect Sync</p>
          </div>
          <div className="relative">
            <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'} border-2 border-white`} />
            <Smartphone className="w-8 h-8 text-slate-400" />
          </div>
        </header>

        {/* Connection Status */}
        <Card className="border-none shadow-sm bg-white/80 backdrop-blur">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${isConnected ? 'bg-green-100' : 'bg-slate-100'}`}>
                  <Activity className={`w-5 h-5 ${isConnected ? 'text-green-600' : 'text-slate-400'}`} />
                </div>
                <div>
                  <p className="font-medium text-sm">Health Connect</p>
                  <p className="text-xs text-slate-500">
                    {isConnected ? 'Ulanish faol' : 'Ulanmagan'}
                  </p>
                </div>
              </div>
              <Button 
                variant={isConnected ? "outline" : "default"} 
                size="sm"
                onClick={toggleConnection}
                className="rounded-full px-6"
              >
                {isConnected ? 'Uzish' : 'Ulanish'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Main Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="border-none shadow-sm overflow-hidden">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-1.5 bg-orange-100 rounded-lg">
                    <Activity className="w-4 h-4 text-orange-600" />
                  </div>
                  <Badge variant="secondary" className="bg-orange-50 text-orange-700 border-none text-[10px]">Qadamlar</Badge>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{data.steps.toLocaleString()}</h3>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Bugun</p>
                </div>
                <Progress value={(data.steps / 10000) * 100} className="h-1 bg-orange-100" />
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="border-none shadow-sm overflow-hidden">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-1.5 bg-blue-100 rounded-lg">
                    <Droplets className="w-4 h-4 text-blue-600" />
                  </div>
                  <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-none text-[10px]">Suv iste'moli</Badge>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{data.waterIntake}</h3>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">ML</p>
                </div>
                <div className="flex gap-1 h-1">
                  {[1,2,3,4,5,6,7,8].map(i => (
                    <div key={i} className={`flex-1 rounded-full ${i <= (data.waterIntake / 250) ? 'bg-blue-500' : 'bg-blue-100'}`} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="border-none shadow-sm overflow-hidden">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-1.5 bg-blue-100 rounded-lg">
                    <Moon className="w-4 h-4 text-blue-600" />
                  </div>
                  <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-none text-[10px]">Uyqu</Badge>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{data.sleepHours}s 20m</h3>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">O'tgan tun</p>
                </div>
                <Progress value={75} className="h-1 bg-blue-100" />
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="border-none shadow-sm overflow-hidden">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-1.5 bg-yellow-100 rounded-lg">
                    <Flame className="w-4 h-4 text-yellow-600" />
                  </div>
                  <Badge variant="secondary" className="bg-yellow-50 text-yellow-700 border-none text-[10px]">Kaloriya</Badge>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{data.calories}</h3>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">KCAL</p>
                </div>
                <Progress value={60} className="h-1 bg-yellow-100" />
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Sync Action */}
        <Card className="border-none shadow-lg bg-slate-900 text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <ArrowRightLeft className="w-24 h-24" />
          </div>
          <CardContent className="pt-6 pb-6 relative z-10">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                <p className="text-xs font-medium text-slate-400 uppercase tracking-widest">Sinxronizatsiya markazi</p>
              </div>
              <div>
                <h2 className="text-xl font-bold">Ma'lumotlarni yuborish</h2>
                <p className="text-sm text-slate-400 mt-1">Health Connect ma'lumotlarini soglomhayot.vercel.app saytiga uzatish.</p>
              </div>
              
              <Button 
                className="w-full bg-white text-slate-900 hover:bg-slate-100 font-bold py-6 rounded-xl"
                onClick={handleSync}
                disabled={isSyncing || !isConnected}
              >
                {isSyncing ? (
                  <>
                    <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                    Yuborilmoqda...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-5 h-5 mr-2" />
                    Hozir sinxronlash
                  </>
                )}
              </Button>
              
              <div className="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800">
                <span>Oxirgi sinxronlash:</span>
                <span>{new Date(data.lastSync).toLocaleTimeString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Info Section */}
        <div className="bg-blue-50 rounded-2xl p-4 flex gap-3 border border-blue-100">
          <AlertCircle className="w-5 h-5 text-blue-500 shrink-0" />
          <p className="text-xs text-blue-700 leading-relaxed">
            Ushbu ilova Android Health Connect API orqali qadamlar, uyqu va suv iste'moli ma'lumotlarini o'qiydi va ularni avtomatik ravishda markaziy serverga yuboradi.
          </p>
        </div>
      </div>
    </div>
  );
}
