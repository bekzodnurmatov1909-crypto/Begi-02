import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.soglomhayot.sync',
  appName: "Sog'lom Hayot Sync",
  webDir: 'dist',
  plugins: {
    HealthConnect: {
      // Health Connect specific configuration if needed
    }
  }
};

export default config;
